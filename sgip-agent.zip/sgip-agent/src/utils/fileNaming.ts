import slugify from "slugify";

export const siteCompact = (addr: string) =>
  slugify(addr.replace(/\s+/g, " "), { lower: false, remove: /[^a-zA-Z0-9\s]/g })
    .replace(/\s+/g, "");

export const dateStamp = () => {
  const d = new Date();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}${mm}${dd}`;
};

export const nameFiles = (addr: string) => {
  const SITE = siteCompact(addr);
  const DATE = dateStamp();
  return {
    bills: (range: string) => `Utility_Bills_${SITE}_${range}.pdf`,
    elj: (ver = "1.0") => `Electric_Load_Justification_${SITE}_v${ver}.pdf`,
    pvw: (dc: number, tilt: number, az: number) =>
      `PVWatts_${SITE}_${dc.toFixed(2)}kWDC_T${Math.round(tilt)}_A${Math.round(az)}_${DATE}.pdf`,
    slj: (ver = "1.0") => `Solar_Load_Justification_${SITE}_v${ver}.pdf`,
    sljPacket: (ver = "1.0") => `Solar_Load_Justification_Packet_${SITE}_v${ver}.pdf`,
    checklist: () => `Submission_Checklist_${SITE}_${DATE}.pdf`,
    zip: () => `SGIP_Packet_${SITE}_${DATE}.zip`
  };
};