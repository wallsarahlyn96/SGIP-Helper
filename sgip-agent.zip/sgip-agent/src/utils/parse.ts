export function last4(s: string) {
  const m = String(s || "").match(/(\d{4})\b/);
  return m ? m[1] : "";
}

export function compactAddress(s: string) {
  return (s || "").replace(/\s+/g, " ").trim();
}

export function parseBillTextToData(text: string): Partial<{
  accountName: string; accountId: string; meterId: string; serviceAddress: string;
  rateSchedule: string; utility: string;
}> {
  const find = (re: RegExp) => (text.match(re) || [])[1]?.trim();
  return {
    accountName: find(/Account\s*Name[:\s]+(.+)/i),
    accountId: find(/Account\s*ID[:\s]+([\d\-]+)/i),
    meterId: find(/Meter\s*(?:ID|Number)[:\s]+([\d\-]+)/i),
    serviceAddress: find(/Service\s*Address[:\s]+(.+)/i),
    rateSchedule: find(/Rate\s*(?:Schedule|Plan)[:\s]+([A-Z0-9\-\s]+)/i),
    utility: find(/Pacific Gas and Electric|PG&E|SCE|SDG&E/i) || "Utility"
  };
}