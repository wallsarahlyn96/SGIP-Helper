export const avgDaily = (kWh: number, days: number) => (days > 0 ? kWh / days : 0);

export const dischargeHours = (usableKwh: number, ratedKw?: number) =>
  ratedKw && ratedKw > 0 ? Math.round((usableKwh / ratedKw) * 100) / 100 : undefined;

export const pv75Required = (usableKwh: number) => usableKwh * 365 * 0.75;

export const tepcCap = (storageTEPC: number, itcPct = 0.3) => storageTEPC * (1 - itcPct);