import "dotenv/config";
import express from "express";
import multer from "multer";
import path from "path";
import fs from "fs/promises";
import { extractBills, extractPlans } from "./services/extract.js";
import { runPVWatts } from "./services/pvwatts.js";
import { combineBillsToPdf, generateElectricLoadJustification, generateSolarLoadJustification, mergeTwoPdfs } from "./services/pdf.js";
import { nameFiles, siteCompact } from "./utils/fileNaming.js";
import { avgDaily, dischargeHours as dh, pv75Required, tepcCap } from "./utils/math.js";
import { zipFiles } from "./services/zip.js";
import type { CalculationResults, ExtractedBillData, ExtractedPlanData } from "./types.js";

const app = express();
const PORT = Number(process.env.PORT || 5173);
const upload = multer({ dest: "uploads/" });

app.use(express.json({ limit: "20mb" }));
app.use(express.urlencoded({ extended: true, limit: "20mb" }));
app.use(express.static("public"));
app.use("/output", express.static("output"));

async function ensureDirs() {
  for (const d of ["uploads", "output"]) {
    try { await fs.mkdir(d, { recursive: true }); } catch {}
  }
}
ensureDirs();

app.post("/api/upload", upload.fields([
  { name: "plans", maxCount: 1 },
  { name: "bills", maxCount: 24 },
  { name: "pvwattsPdf", maxCount: 1 }
]), async (req: any, res) => {
  const plans = (req.files as any)?.plans?.[0]?.path;
  const bills = ((req.files as any)?.bills || []).map((f: any) => f.path);
  const pvwattsPdf = (req.files as any)?.pvwattsPdf?.[0]?.path;
  const { address } = req.body;
  if (!plans || bills.length === 0 || !address) {
    return res.status(400).json({ error: "Upload plans, at least one bill, and provide project address." });
  }
  res.json({ plans, bills, pvwattsPdf, address });
});

app.post("/api/process", async (req, res) => {
  const { plans, bills, address, storageTEPC, storageITC = 30 } = req.body as {
    plans: string; bills: string[]; address: string; storageTEPC?: number; storageITC?: number;
  };

  const outDir = "output";
  const SITE = siteCompact(address);
  const namer = nameFiles(address);

  // 1) Extract
  const billDataPartial = await extractBills(bills);
  const planDataPartial = await extractPlans(plans);

  const billData: ExtractedBillData = {
    accountName: billDataPartial.accountName || "",
    accountId: billDataPartial.accountId || "",
    meterId: billDataPartial.meterId || "",
    serviceAddress: billDataPartial.serviceAddress || address,
    rateSchedule: billDataPartial.rateSchedule || "",
    utility: billDataPartial.utility || "Utility",
    billingPeriods: billDataPartial.billingPeriods || []
  };
  const planData: ExtractedPlanData = {
    pvModules: [],
    pvPower: planDataPartial.pvPower || { dcKw: 0, acKw: 0 },
    inverters: [],
    ess: planDataPartial.ess || { make: "", model: "", usableKwh: 0 },
    pvOrientation: planDataPartial.pvOrientation || { tilt: 20, azimuth: 180 }
  };

  // 2) Combine bills
  const billRange = (() => {
    const bps = billData.billingPeriods;
    const first = bps[0]?.startDate?.slice(6, 10) + bps[0]?.startDate?.slice(0, 2);
    const last = bps[bps.length - 1]?.endDate?.slice(6, 10) + bps[bps.length - 1]?.endDate?.slice(0, 2);
    return (first && last) ? `${first}-${last}` : "Bills";
  })();
  const billsOut = path.join(outDir, namer.bills(billRange));
  await combineBillsToPdf(bills, billsOut);

  // 3) PVWatts
  let pvw: any = null;
  try {
    pvw = await runPVWatts({
      address,
      dcKw: planData.pvPower.dcKw || 1,
      tilt: planData.pvOrientation.tilt,
      azimuth: planData.pvOrientation.azimuth,
      siteAddrCompact: SITE,
      outputDir: outDir
    });
  } catch (e: any) {
    pvw = { error: e.message };
  }

  // 4) Calculations
  const calc: CalculationResults = { averageDailyKwh: [] };
  billData.billingPeriods.forEach(p => calc.averageDailyKwh.push(avgDaily(p.kWh, p.days)));
  calc.dischargeHours = dh(planData.ess.usableKwh, planData.ess.ratedKw);
  calc.pvChargingRequired = pv75Required(planData.ess.usableKwh || 0);
  if (pvw?.annualKwh) calc.pvChargingTest = pvw.annualKwh >= (calc.pvChargingRequired || 0);
  if (storageTEPC) calc.tepcCap = tepcCap(storageTEPC, (storageITC as number) / 100);

  // 5) Electric Load Justification
  const elj = await generateElectricLoadJustification({
    addr: address, bills: billData, calc, outDir
  });

  // 6) Solar Load Justification + Packet
  let slj: string | undefined;
  let sljPacket: string | undefined;
  if (pvw?.annualKwh) {
    slj = await generateSolarLoadJustification({
      addr: address, plan: planData, pvw, calc, outDir
    });
    const packetOut = path.join(outDir, nameFiles(address).sljPacket("1.0"));
    await mergeTwoPdfs(slj, pvw.pdfPath, packetOut);
    sljPacket = packetOut;
  }

  res.json({
    ok: true,
    extracted: { billData, planData },
    pvwatts: pvw?.annualKwh ? pvw : { error: pvw?.error || "PVWatts not run" },
    outputs: {
      utilityBillsCombined: `/output/${path.basename(billsOut)}`,
      electricLoadJustification: `/output/${path.basename(elj)}`,
      pvWattsReport: pvw?.pdfPath ? `/output/${path.basename(pvw.pdfPath)}` : undefined,
      solarLoadJustification: slj ? `/output/${path.basename(slj)}` : undefined,
      solarLoadJustificationPacket: sljPacket ? `/output/${path.basename(sljPacket)}` : undefined
    },
    calculations: calc
  });
});

app.post("/api/zip", async (req, res) => {
  const { files, address } = req.body as { files: string[]; address: string };
  const out = path.join("output", nameFiles(address).zip());
  const absolute = files.filter(Boolean).map(f => path.join(process.cwd(), f.replace(/^\/+/, "")));
  await zipFiles(absolute, out);
  res.json({ zip: `/output/${path.basename(out)}` });
});

app.listen(PORT, () => {
  console.log(`SGIP agent running at http://localhost:${PORT}`);
});