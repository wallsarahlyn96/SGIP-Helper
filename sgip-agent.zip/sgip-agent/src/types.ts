export type BillingPeriod = {
  startDate: string;
  endDate: string;
  days: number;
  kWh: number;
  demand?: number;
};

export type ExtractedBillData = {
  accountName: string;
  accountId: string;
  meterId: string;
  serviceAddress: string;
  rateSchedule: string;
  utility: string;
  billingPeriods: BillingPeriod[];
};

export type PVModule = { make: string; model: string; quantity: number };
export type Inverter = { make: string; model: string; acKw: number };
export type Optimizer = { make: string; model: string };

export type ExtractedPlanData = {
  pvModules: PVModule[];
  pvPower: { dcKw: number; acKw: number };
  inverters: Inverter[];
  optimizers?: Optimizer[];
  ess: { make: string; model: string; usableKwh: number; ratedKw?: number };
  pvOrientation: { tilt: number; azimuth: number };
  singleLinePageRef?: string;
  meteringPoints?: string;
};

export type PVWattsData = {
  annualKwh: number;
  monthlyKwh: number[];
  capacityFactor?: number;
  solradAnnual?: number;
  solradMonthly?: number[];
  stationInfo?: Record<string, unknown>;
  pdfPath?: string;
};

export type CalculationResults = {
  averageDailyKwh: number[];
  annualizedKwh?: number;
  dischargeHours?: number;
  pvChargingRequired?: number;
  pvChargingTest?: boolean;
  tepcCap?: number;
  incentiveExpected?: number;
};

export type GeneratedDocuments = {
  utilityBillsCombined?: string;
  electricLoadJustification?: string;
  pvWattsReport?: string;
  solarLoadJustification?: string;
  solarLoadJustificationPacket?: string;
  submissionChecklist?: string;
  zipPath?: string;
};