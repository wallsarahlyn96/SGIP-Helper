import * as fs from "fs/promises";
import * as path from "path";
import { BlobWriter, ZipWriter } from "@zip.js/zip.js";

export async function zipFiles(files: string[], outPath: string) {
  const writer = new ZipWriter(new BlobWriter("application/zip"));
  for (const f of files) {
    const data = await fs.readFile(f);
    await writer.add(path.basename(f), new Response(data).body as any);
  }
  const blob = await writer.close();
  const buf = Buffer.from(await blob.arrayBuffer());
  await fs.writeFile(outPath, buf);
}