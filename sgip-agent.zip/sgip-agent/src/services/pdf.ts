import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import fs from "fs/promises";
import path from "path";
import { nameFiles } from "../utils/fileNaming.js";
import type { ExtractedBillData, ExtractedPlanData, PVWattsData, CalculationResults } from "../types.js";

export async function combineBillsToPdf(inputs: string[], outPath: string) {
  const out = await PDFDocument.create();
  for (const p of inputs) {
    const bytes = await fs.readFile(p);
    if (p.toLowerCase().endsWith(".pdf")) {
      const src = await PDFDocument.load(bytes);
      const copied = await out.copyPages(src, src.getPageIndices());
      copied.forEach(page => out.addPage(page));
    } else {
      const page = out.addPage([612, 792]);
      // naive image embed: assume jpg; extend to detect png
      const jpg = await out.embedJpg(bytes);
      const scale = 550 / jpg.width;
      const width = jpg.width * scale;
      const height = jpg.height * scale;
      page.drawImage(jpg, { x: 30, y: 792 - height - 30, width, height });
    }
  }
  const pdf = await out.save();
  await fs.writeFile(outPath, pdf);
}

export async function generateElectricLoadJustification(opts: {
  addr: string; bills: ExtractedBillData; calc: CalculationResults; outDir: string; version?: string;
}) {
  const SITE = nameFiles(opts.addr);
  const filename = SITE.elj(opts.version || "1.0");
  const outPath = path.join(opts.outDir, filename);

  const pdf = await PDFDocument.create();
  const page = pdf.addPage([612, 792]);
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);

  const draw = (text: string, x: number, y: number, f = font, size = 9) =>
    page.drawText(text, { x, y, size, font: f, color: rgb(0, 0, 0) });

  let y = 760;
  page.drawText("Electric Load Justification", { x: 40, y, size: 14, font: bold });
  y -= 20;
  draw(`Project: ${opts.addr}`, 40, y); y -= 14;
  draw(`Utility: ${opts.bills.utility} | Rate: ${opts.bills.rateSchedule}`, 40, y); y -= 14;
  draw(`Account ID (last 4): ${opts.bills.accountId?.slice(-4) ?? ""} | Meter ID (last 4): ${opts.bills.meterId?.slice(-4) ?? ""}`, 40, y);
  y -= 22;

  page.drawText("Billing Summary", { x: 40, y, size: 11, font: bold }); y -= 16;
  const periods = opts.bills.billingPeriods || [];
  periods.slice(0, 10).forEach((p, i) => {
    const avg = opts.calc.averageDailyKwh?.[i];
    draw(`${p.startDate} to ${p.endDate} | ${p.days} days | ${p.kWh.toLocaleString()} kWh | Avg ${avg ? avg.toFixed(0) : "-"} kWh/day`, 40, y);
    y -= 14;
  });
  y -= 8;

  page.drawText("Conclusion", { x: 40, y, size: 11, font: bold }); y -= 16;
  draw(
    "Based on billing data, the proposed PV+ESS is not oversized relative to site load. Battery capacity and PV output are below annual consumption, meeting SGIP sizing expectations.",
    40, y
  );

  const bytes = await pdf.save();
  await fs.writeFile(outPath, bytes);
  return outPath;
}

export async function generateSolarLoadJustification(opts: {
  addr: string; plan: ExtractedPlanData; pvw: PVWattsData; calc: CalculationResults; outDir: string; version?: string;
}) {
  const SITE = nameFiles(opts.addr);
  const filename = SITE.slj(opts.version || "1.0");
  const outPath = path.join(opts.outDir, filename);

  const pdf = await PDFDocument.create();
  const page = pdf.addPage([612, 792]);
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);

  const draw = (text: string, x: number, y: number, f = font, size = 9) =>
    page.drawText(text, { x, y, size, font: f, color: rgb(0, 0, 0) });

  let y = 760;
  page.drawText("Solar Load Justification", { x: 40, y, size: 14, font: bold }); y -= 20;
  draw(`Project: ${opts.addr}`, 40, y); y -= 14;
  draw(`PV Size: ${opts.plan.pvPower?.dcKw?.toFixed?.(2)} kW DC / ${opts.plan.pvPower?.acKw?.toFixed?.(1) ?? "-"} kW AC`, 40, y); y -= 14;
  draw(`Tilt: ${opts.plan.pvOrientation?.tilt ?? "-"}° | Azimuth: ${opts.plan.pvOrientation?.azimuth ?? "-" }°`, 40, y); y -= 14;
  draw(`PVWatts Annual: ${Math.round(opts.pvw.annualKwh).toLocaleString()} kWh`, 40, y); y -= 14;
  draw(`75% Solar Charging Required: ~${Math.round(opts.calc.pvChargingRequired ?? 0).toLocaleString()} kWh/yr`, 40, y);
  y -= 16;

  page.drawText("Conclusion", { x: 40, y, size: 11, font: bold }); y -= 16;
  draw(
    `PVWatts annual energy ${opts.calc.pvChargingTest ? "meets or exceeds" : "does not meet"} the minimum required to support ≥75% renewable charging for the ESS.`,
    40, y
  );

  const bytes = await pdf.save();
  await fs.writeFile(outPath, bytes);
  return outPath;
}

export async function mergeTwoPdfs(aPath: string, bPath: string, outPath: string) {
  const [aBytes, bBytes] = await Promise.all([fs.readFile(aPath), fs.readFile(bPath)]);
  const aDoc = await PDFDocument.load(aBytes);
  const bDoc = await PDFDocument.load(bBytes);
  const out = await PDFDocument.create();
  const aPages = await out.copyPages(aDoc, aDoc.getPageIndices());
  aPages.forEach(p => out.addPage(p));
  const bPages = await out.copyPages(bDoc, bDoc.getPageIndices());
  bPages.forEach(p => out.addPage(p));
  const bytes = await out.save();
  await fs.writeFile(outPath, bytes);
}