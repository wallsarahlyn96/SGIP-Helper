import fetch from "node-fetch";
import { PVWattsData } from "../types.js";
import PDFDocument from "pdfkit";
import fs from "fs";
import { nameFiles } from "../utils/fileNaming.js";

const NREL = process.env.NREL_API_KEY || "";

async function geocode(address: string): Promise<{ lat: number; lon: number }> {
  const url = new URL("https://nominatim.openstreetmap.org/search");
  url.searchParams.set("q", address);
  url.searchParams.set("format", "json");
  url.searchParams.set("limit", "1");
  const res = await fetch(url.toString(), { headers: { "User-Agent": "sgip-agent/1.0" } });
  const data: any[] = await res.json();
  if (!data?.length) throw new Error("Geocoding failed: no results");
  return { lat: Number(data[0].lat), lon: Number(data[0].lon) };
}

export async function runPVWatts(opts: {
  address: string; dcKw: number; tilt: number; azimuth: number;
  losses?: number; arrayType?: number; moduleType?: number;
  siteAddrCompact: string; outputDir: string;
}): Promise<PVWattsData> {
  if (!NREL) throw new Error("Missing NREL API key. Set NREL_API_KEY in .env");

  const losses = Number.isFinite(opts.losses!) ? (opts.losses as number) : 14;
  const arrayType = Number.isFinite(opts.arrayType!) ? (opts.arrayType as number) : 1;
  const moduleType = Number.isFinite(opts.moduleType!) ? (opts.moduleType as number) : 0;

  const { lat, lon } = await geocode(opts.address);

  const url = new URL("https://developer.nrel.gov/api/pvwatts/v8.json");
  url.searchParams.set("api_key", NREL);
  url.searchParams.set("system_capacity", String(opts.dcKw));
  url.searchParams.set("module_type", String(moduleType));
  url.searchParams.set("losses", String(losses));
  url.searchParams.set("array_type", String(arrayType));
  url.searchParams.set("tilt", String(opts.tilt));
  url.searchParams.set("azimuth", String(opts.azimuth));
  url.searchParams.set("timeframe", "monthly");
  url.searchParams.set("dataset", "nsrdb");
  url.searchParams.set("lat", String(lat));
  url.searchParams.set("lon", String(lon));
  url.searchParams.set("radius", "0");

  const res = await fetch(url.toString());
  const json: any = await res.json();

  if (json?.errors?.length) {
    throw new Error(`PVWatts error: ${json.errors.join("; ")}`);
  }
  const out = json?.outputs;
  if (!out?.ac_annual || !out?.ac_monthly) {
    throw new Error("PVWatts incomplete response");
  }

  const filename = nameFiles(opts.siteAddrCompact).pvw(opts.dcKw, opts.tilt, opts.azimuth);
  const pdfPath = `${opts.outputDir}/${filename}`;
  await new Promise<void>((resolve, reject) => {
    const doc = new PDFDocument({ size: "LETTER", margin: 40 });
    const stream = fs.createWriteStream(pdfPath);
    doc.pipe(stream);

    doc.fontSize(16).text("PVWatts® (V8) Production Summary", { align: "left" });
    doc.moveDown(0.5);
    doc.fontSize(9).text(`Address: ${opts.address}`);
    doc.text(`Lat/Lon: ${lat.toFixed(4)}, ${lon.toFixed(4)}`);
    doc.text(`Weather Dataset: NSRDB (TMY)`);
    doc.moveDown();

    doc.fontSize(11).text("Inputs", { underline: true });
    doc.fontSize(9)
      .text(`DC Size: ${opts.dcKw.toFixed(2)} kW`)
      .text(`Tilt: ${opts.tilt}°  |  Azimuth: ${opts.azimuth}°`)
      .text(`Array Type: ${arrayType} (1=fixed roof)  |  Module Type: ${moduleType} (0=standard)`)
      .text(`Losses: ${losses}%`);
    doc.moveDown();

    doc.fontSize(11).text("Outputs", { underline: true });
    doc.fontSize(9)
      .text(`Annual AC Energy: ${Math.round(out.ac_annual).toLocaleString()} kWh`)
      .text(`Capacity Factor: ${out.capacity_factor?.toFixed?.(2) ?? "—"} %`);
    doc.moveDown();

    doc.fontSize(10).text("Monthly AC Energy (kWh)", { underline: true });
    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    out.ac_monthly.forEach((v: number, i: number) => {
      doc.fontSize(9).text(`${months[i]}: ${Math.round(v).toLocaleString()}`);
    });

    doc.moveDown(1);
    doc.fontSize(8).text("Source: NREL PVWatts® API v8  |  https://developer.nrel.gov");
    doc.end();
    stream.on("finish", () => resolve());
    stream.on("error", reject);
  });

  return {
    annualKwh: Number(out.ac_annual),
    monthlyKwh: out.ac_monthly.map((n: number) => Number(n)),
    capacityFactor: out.capacity_factor ? Number(out.capacity_factor) : undefined,
    solradAnnual: out.solrad_annual ? Number(out.solrad_annual) : undefined,
    solradMonthly: out.solrad_monthly?.map((n: number) => Number(n)),
    stationInfo: json.station_info,
    pdfPath
  };
}