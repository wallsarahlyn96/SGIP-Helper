import pdfParse from "pdf-parse";
import * as fs from "fs/promises";
import path from "path";
import Tesseract from "tesseract.js";
import { parseBillTextToData } from "../utils/parse.js";
import type { ExtractedBillData, ExtractedPlanData } from "../types.js";

export async function extractTextFromPdf(filePath: string) {
  const dataBuffer = await fs.readFile(filePath);
  const res = await pdfParse(dataBuffer);
  return res.text || "";
}

export async function ocrImage(filePath: string) {
  const { data } = await Tesseract.recognize(filePath, "eng", { logger: () => {} });
  return data.text || "";
}

export async function extractBills(files: string[]): Promise<Partial<ExtractedBillData>> {
  const periods: any[] = [];
  const base: Partial<ExtractedBillData> = {};
  for (const f of files) {
    const ext = path.extname(f).toLowerCase();
    const text = ext === ".pdf" ? await extractTextFromPdf(f) : await ocrImage(f);
    const core = parseBillTextToData(text);

    const kWh = Number((text.match(/(\d{3,7})\s*kWh\b/i) || [])[1]);
    const days = Number((text.match(/(\d{1,3})\s*days\b/i) || [])[1]);
    const start = (text.match(/(\d{1,2}\/\d{1,2}\/\d{2,4}).{0,10}to/i) || [])[1] || "";
    const end = (text.match(/to.{0,10}(\d{1,2}\/\d{1,2}\/\d{2,4})/i) || [])[1] || "";

    periods.push({
      startDate: start, endDate: end,
      days: Number.isFinite(days) ? days : 30,
      kWh: Number.isFinite(kWh) ? kWh : 0
    });

    Object.assign(base, core, { billingPeriods: periods });
  }
  return base;
}

export async function extractPlans(plansPdf: string): Promise<Partial<ExtractedPlanData>> {
  const text = await extractTextFromPdf(plansPdf);

  const dcKw = Number((text.match(/Total\s*PV[\s\S]{0,40}?(\d{1,3}(\.\d{1,2})?)\s*kW\s*DC/i) || [])[1]) || 
                Number((text.match(/(\d{1,3}(\.\d{1,2})?)\s*kW\s*DC/i) || [])[1]);
  const acKw = Number((text.match(/(\d{1,3}(\.\d{1,2})?)\s*kW\s*AC/i) || [])[1]);
  const tilt = Number((text.match(/tilt[:\s]+(\d{1,2})[°]?/i) || [])[1]) || 14;
  const az = Number((text.match(/azimuth[:\s]+(\d{1,3})[°]?/i) || [])[1]) || 180;

  const essMake = (text.match(/Deye|Tesla|Enphase|LG Chem|BYD/i) || [""])[0] || "ESS";
  const essModel = (text.match(/GE[-\s]?F60|Powerwall\s*2|Encharge|RESU/i) || [""])[0] || "Model";
  const usable = Number((text.match(/usable\s*(\d{1,3}(\.\d{1,2})?)\s*kWh/i) || [])[1]) ||
                 Number((text.match(/(\d{1,3}(\.\d{1,2})?)\s*kWh\s*usable/i) || [])[1]) || 55.29;
  const ratedKw = Number((text.match(/(\d{1,2}(\.\d{1,2})?)\s*kW\s*(?:cont|continuous|rated)/i) || [])[1]);

  return {
    pvPower: { dcKw: dcKw || 0, acKw: acKw || 0 },
    pvOrientation: { tilt, azimuth: az },
    ess: { make: essMake, model: essModel, usableKwh: usable, ratedKw }
  };
}