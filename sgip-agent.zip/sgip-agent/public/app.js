const state = { upload: null, outputs: null, address: "" };

const $ = sel => document.querySelector(sel);

document.getElementById("uploadForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  state.address = fd.get("address");
  const res = await fetch("/api/upload", { method: "POST", body: fd });
  const json = await res.json();
  document.getElementById("uploadOut").textContent = JSON.stringify(json, null, 2);
  if (json.error) return;
  state.upload = json;
  alert("Uploaded. Now click 'Process'.");
});

document.getElementById("procForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!state.upload) { alert("Upload first."); return; }
  const fd = new FormData(e.target);
  const body = {
    plans: state.upload.plans,
    bills: state.upload.bills,
    address: state.upload.address,
    storageTEPC: Number(fd.get("storageTEPC") || 0),
    storageITC: Number(fd.get("storageITC") || 30)
  };
  const res = await fetch("/api/process", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const json = await res.json();
  renderResults(json);
  state.outputs = json.outputs || {};
});

function link(label, href) {
  if (!href) return "";
  return `<div><a href="${href}" target="_blank" rel="noopener">${label}</a></div>`;
}

function renderResults(r) {
  const el = document.getElementById("results");
  if (!r?.ok) { el.innerHTML = `<div class="mono small">${JSON.stringify(r,null,2)}</div>`; return; }
  const out = r.outputs || {};
  const calc = r.calculations || {};
  const pvw = r.pvwatts;
  el.innerHTML = `
    <h3>Outputs</h3>
    ${link("Utility Bills (Combined)", out.utilityBillsCombined)}
    ${link("Electric Load Justification", out.electricLoadJustification)}
    ${link("PVWatts Summary", out.pvWattsReport)}
    ${link("Solar Load Justification", out.solarLoadJustification)}
    ${link("Solar Load Justification Packet", out.solarLoadJustificationPacket)}
    <h3>PVWatts</h3>
    <div class="mono small">${pvw?.error ? pvw.error : JSON.stringify({ annualKwh: pvw.annualKwh, monthlyKwh: pvw.monthlyKwh }, null, 2)}</div>
    <h3>Calculations</h3>
    <div class="mono small">${JSON.stringify(calc, null, 2)}</div>
  `;
}

document.getElementById("zipBtn").addEventListener("click", async () => {
  if (!state.outputs) { alert("Process first."); return; }
  const files = Object.values(state.outputs).filter(Boolean);
  const res = await fetch("/api/zip", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ files, address: state.address })
  });
  const json = await res.json();
  document.getElementById("zipOut").innerHTML = json.zip ? `<a href="${json.zip}" target="_blank" rel="noopener">Download ZIP</a>` : "Error.";
});